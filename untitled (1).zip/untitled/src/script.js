const menuItems = [
  {
    id: 1,
    name: "Baratarkari",
    price: 30,
    image: "https://i.imgur.com/ZwRscZf.png"
  },
  {
    id: 2,
    name: "Ittilitarkari",
    price: 35,
    image: "https://i.imgur.com/O8VugYZ.png"
  },
  {
    id: 3,
    name: "Samosa",
    price: 10,
    image: "https://i.imgur.com/9zD2FfE.jpg"
  },
  {
    id: 4,
    name: "Aluchop",
    price: 15,
    image: "https://i.imgur.com/xUuv7Io.png"
  }
];

let cart = [];

const menuDiv = document.getElementById("menu");

menuItems.forEach(item => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${item.image}" alt="${item.name}">
    <h3>${item.name}</h3>
    <p>₹${item.price}</p>
    <button onclick="addToCart(${item.id})">Add to Cart</button>
  `;
  menuDiv.appendChild(card);
});

function addToCart(id) {
  const item = menuItems.find(m => m.id === id);
  cart.push(item);
  updateCartCount();
}

function updateCartCount() {
  document.getElementById("cart-count").textContent = cart.length;
}

function toggleCart() {
  const modal = document.getElementById("cartModal");
  if (modal.style.display === "flex") {
    modal.style.display = "none";
  } else {
    renderCartItems();
    modal.style.display = "flex";
  }
}

function renderCartItems() {
  const cartList = document.getElementById("cart-items");
  const cartTotal = document.getElementById("cart-total");
  cartList.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    total += item.price;
    const li = document.createElement("li");
    li.textContent = `${item.name} - ₹${item.price}`;
    cartList.appendChild(li);
  });

  cartTotal.textContent = total;
}

function checkout() {
  alert("Thanks for ordering! Your food is on the way 🍽️");
  cart = [];
  updateCartCount();
  toggleCart();
}
